<?php
if (!defined('ABSPATH')) exit;
function psp_render_settings_page(){
    if(!empty($_POST['psp_save'])){
        check_admin_referer('psp_settings');
        update_option('psp_quality', intval($_POST['quality']));
        update_option('psp_max_width', intval($_POST['max_width']));
        update_option('psp_max_height', intval($_POST['max_height']));
        update_option('psp_min_size', floatval($_POST['min_size']));
        update_option('psp_auto_compress', isset($_POST['auto_compress']));
        echo '<div class="updated"><p>已保存设置！</p></div>';
    }
    $quality = get_option('psp_quality', 80);
    $mw = get_option('psp_max_width', 2000);
    $mh = get_option('psp_max_height', 2000);
    $min_size = get_option('psp_min_size', 0.1);
    $auto_compress = get_option('psp_auto_compress', true);
?>
<div class="wrap">
<h1 style="margin-bottom:20px;">📦 Pic Smaller PRO — 图片压缩优化</h1>
<div style="max-width:600px;background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
<form method="POST">
<?php wp_nonce_field('psp_settings'); ?>
<h2>⚙ 压缩设置</h2>
<table class="form-table">
<tr>
<th><label>压缩质量：</label></th>
<td><input type="number" name="quality" value="<?php echo $quality; ?>" min="1" max="100" style="width:120px;"> (1-100，数值越大质量越好)</td>
</tr>
<tr>
<th><label>最大宽度：</label></th>
<td><input type="number" name="max_width" value="<?php echo $mw; ?>" style="width:120px;"> 像素</td>
</tr>
<tr>
<th><label>最大高度：</label></th>
<td><input type="number" name="max_height" value="<?php echo $mh; ?>" style="width:120px;"> 像素</td>
</tr>
<tr>
<th><label>最小压缩大小：</label></th>
<td><input type="number" name="min_size" value="<?php echo $min_size; ?>" min="0" max="10" step="0.1" style="width:120px;"> MB（低于此大小的文件不压缩）</td>
</tr>
<tr>
<th><label>上传前压缩：</label></th>
<td><label><input type="checkbox" name="auto_compress" <?php checked($auto_compress); ?>> 启用上传前自动压缩</label></td>
</tr>
</table>
<input type="submit" name="psp_save" class="button button-primary" value="保存设置">
</form>
</div>

<h2 style="margin-top:30px;">🖼 批量压缩旧图片</h2>
<p>压缩所有已上传的图片（此操作可能需要较长时间）</p>
<button id="psp-start-batch" class="button button-secondary" style="font-size:16px;padding:10px 20px;">开始批量压缩</button>
<div id="psp-result" style="margin-top:15px;font-weight:bold;"></div>

<h2 style="margin-top:30px;">🔍 系统诊断</h2>
<div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;margin-bottom:20px;">
<?php
$upload_dir = wp_upload_dir();
$imagick_available = class_exists('Imagick');
$gd_available = function_exists('imagecreatefromjpeg') || function_exists('imagecreatefrompng');
$memory_limit = ini_get('memory_limit');
$max_upload_size = wp_max_upload_size();
?>
<table class="widefat">
<tr>
<th style="width:200px;">项目</th>
<th>状态</th>
</tr>
<tr>
<td><strong>图片存储位置</strong></td>
<td><?php echo esc_html($upload_dir['basedir']); ?></td>
</tr>
<tr>
<td><strong>Imagick 扩展</strong></td>
<td><?php echo $imagick_available ? '<span style="color:#46b450;">✓ 已安装</span>' : '<span style="color:#dc3232;">✗ 未安装（将使用 GD）</span>'; ?></td>
</tr>
<tr>
<td><strong>GD 扩展</strong></td>
<td><?php echo $gd_available ? '<span style="color:#46b450;">✓ 已安装</span>' : '<span style="color:#dc3232;">✗ 未安装</span>'; ?></td>
</tr>
<tr>
<td><strong>PHP 内存限制</strong></td>
<td><?php echo esc_html($memory_limit); ?></td>
</tr>
<tr>
<td><strong>最大上传大小</strong></td>
<td><?php echo size_format($max_upload_size); ?></td>
</tr>
</table>
</div>

<h2 style="margin-top:30px;">📋 使用说明</h2>
<div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;">
<ul style="line-height:1.8;">
<li><strong>上传前压缩：</strong>在媒体库页面（upload.php）和新建媒体页面（media-new.php）会显示"上传前自动压缩"开关，启用后上传的图片会自动压缩。</li>
</ul>
</div>

<h2 style="margin-top:30px;">❓ 常见问题</h2>
<div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;">
<h3>为什么有的图片可以压缩有的不行？</h3>
<p>图片压缩失败的可能原因：</p>
<ul style="line-height:1.8;">
<li><strong>文件格式不支持：</strong>只支持 JPEG、PNG、GIF 格式</li>
<li><strong>文件权限问题：</strong>文件不可读或不可写（检查文件权限）</li>
<li><strong>文件损坏：</strong>图片文件可能已损坏</li>
<li><strong>内存不足：</strong>图片太大，服务器内存不够处理</li>
<li><strong>服务器扩展缺失：</strong>需要 Imagick 或 GD 扩展（至少一个）</li>
</ul>

<h3>上传前压缩是纯本地处理吗？</h3>
<p><strong>是的！</strong>上传前压缩完全在<strong>客户端浏览器</strong>中进行，参考了 <a href="https://github.com/joye61/pic-smaller" target="_blank">Pic Smaller</a> 的纯本地压缩方案：</p>
<ul style="line-height:1.8;">
<li><strong>✅ 纯客户端压缩：</strong>使用浏览器 Canvas API 和 OffscreenCanvas（如果支持）</li>
<li><strong>✅ 不涉及服务器：</strong>压缩过程完全在用户浏览器中完成，不会上传到服务器</li>
<li><strong>✅ 安全隐私：</strong>图片数据不会发送到任何第三方服务器</li>
<li><strong>✅ 性能优化：</strong>使用 OffscreenCanvas 和高质量渲染算法</li>
<li><strong>✅ 自动降级：</strong>不支持 OffscreenCanvas 的浏览器自动使用 Canvas API</li>
</ul>
<p><strong>工作流程：</strong>选择图片 → 浏览器压缩 → 上传压缩后的图片 → 服务器保存</p>

<h3>压缩后的图片存储在哪里？会影响服务器速度吗？</h3>
<p><strong>存储位置：</strong></p>
<ul style="line-height:1.8;">
<li>所有图片（包括压缩后的）都存储在：<code><?php echo esc_html($upload_dir['basedir']); ?></code></li>
<li>压缩是<strong>直接替换原文件</strong>，不会创建副本，所以不会占用额外空间</li>
</ul>
<p><strong>对服务器速度的影响：</strong></p>
<ul style="line-height:1.8;">
<li><strong>✅ 压缩后文件更小</strong> → 上传/下载更快 → 服务器负载降低</li>
<li><strong>✅ 减少存储空间</strong> → 节省服务器磁盘空间</li>
<li><strong>✅ 上传前压缩</strong>在客户端完成，不消耗服务器资源</li>
<li><strong>✅ 批量压缩</strong>会消耗服务器 CPU 和内存，但只在压缩时消耗，完成后不影响</li>
<li><strong>⚠️ 批量压缩大量图片</strong>时可能会暂时占用较多资源，建议分批处理</li>
</ul>
<p><strong>总结：</strong>压缩图片通常能<strong>提升</strong>服务器性能，因为文件更小，传输更快，存储更少。上传前压缩在客户端完成，完全不消耗服务器资源。</p>
</div>
</div>
<?php } ?>
