jQuery(function($){
    // Settings page batch compress
    $("#psp-start-batch").on("click", function(){
        var $btn = $(this);
        var $result = $("#psp-result");
        $btn.prop('disabled', true).text('处理中...');
        $result.text("处理中，请稍候...").css("color", "#666");
        
        $.post(pspData.ajaxurl || ajaxurl, {
            action: "psp_batch_compress",
            nonce: pspData.batchNonce,
            batch_action: "compress"
        }, function(r){
            if(r.success){
                $result.html(r.data).css("color", "#46b450");
            } else {
                $result.text(r.data || "处理失败").css("color", "#dc3232");
            }
            $btn.prop('disabled', false).text('开始批量压缩');
        }).fail(function(){
            $result.text("请求失败，请重试").css("color", "#dc3232");
            $btn.prop('disabled', false).text('开始批量压缩');
        });
    });

    // Add compress toggle button to upload pages
    if($('#wpbody-content').length && (window.location.href.indexOf('upload.php') > -1 || window.location.href.indexOf('media-new.php') > -1)){
        addUploadToggle();
    }

    function addUploadToggle(){
        var $toolbar = $('.wp-filter, .media-toolbar').first();
        if($toolbar.length){
            var toggleHtml = '<div class="psp-upload-toggle" style="margin-left: 15px; display: inline-flex; align-items: center; gap: 8px;">' +
                '<label style="display: flex; align-items: center; cursor: pointer;">' +
                '<input type="checkbox" id="psp-auto-compress-toggle" ' + (pspData.autoCompress ? 'checked' : '') + '>' +
                '<span style="margin-left: 5px;">上传前自动压缩</span>' +
                '</label>' +
                '</div>';
            $toolbar.append(toggleHtml);
            
            $('#psp-auto-compress-toggle').on('change', function(){
                var enabled = $(this).is(':checked');
                $.post(pspData.ajaxurl || ajaxurl, {
                    action: 'psp_toggle_auto_compress',
                    nonce: pspData.nonce,
                    enabled: enabled ? 1 : 0
                });
            });
        }
    }

    // Track files being compressed to avoid duplicate processing
    var compressingFiles = new Set();
    
    // Intercept file upload for pre-compression
    // Method 1: Hook into file input change event (for direct file inputs)
    // Disabled to avoid conflict with plupload - plupload handles WordPress uploads
    // $(document).on('change', 'input[type="file"][accept*="image"], input[type="file"]:not([accept])', function(e){
    //     // This method conflicts with plupload, disabled
    // });

    // Method 2: Hook into plupload (most reliable for WordPress media uploader)
    // Optimized: Batch compress all files first, then upload
    if(typeof plupload !== 'undefined'){
        // Store compressed files
        var compressedFileMap = {};
        var batchCompressing = false;
        var batchCompressQueue = [];
        
        // Hook into FilesAdded to batch compress files
        $(document).on('plupload:FilesAdded', function(e, uploader, files){
            var toggle = $('#psp-auto-compress-toggle');
            if(!toggle.length || !toggle.is(':checked')) return;
            
            // Stop uploader from starting automatically
            uploader.stop();
            
            // Collect all image files that need compression
            var imageFiles = [];
            files.forEach(function(file){
                if(file.type && file.type.match(/^image\//)){
                    var fileId = file.id || file.name + file.size;
                    if(!compressedFileMap[fileId] && !compressingFiles.has(fileId)){
                        imageFiles.push(file);
                    }
                }
            });
            
            if(imageFiles.length === 0){
                // No images to compress, start upload
                uploader.start();
                return;
            }
            
            // Show batch compression status
            if(uploader && uploader.settings && uploader.settings.container){
                var $container = $(uploader.settings.container);
                var $status = $container.find('.psp-compressing-status');
                if(!$status.length){
                    $status = $('<div class="psp-compressing-status" style="padding:15px;background:#e7f3ff;border:1px solid #2196F3;margin:10px 0;border-radius:4px;"><div style="display:flex;align-items:center;gap:10px;"><div class="psp-spinner" style="border:3px solid #f3f3f3;border-top:3px solid #2196F3;border-radius:50%;width:20px;height:20px;animation:spin 1s linear infinite;"></div><div><strong>正在批量压缩图片...</strong><div class="psp-progress-text" style="font-size:12px;color:#666;margin-top:5px;">准备中...</div></div></div></div>');
                    $container.prepend($status);
                    // Add spinner animation
                    if(!$('style#psp-spinner-style').length){
                        $('head').append('<style id="psp-spinner-style">@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>');
                    }
                }
                $status.show();
            }
            
            // Batch compress all files
            batchCompressing = true;
            var totalFiles = imageFiles.length;
            var compressedCount = 0;
            var failedCount = 0;
            
            function updateProgress(current, total, text){
                var $progressText = $('.psp-progress-text');
                if($progressText.length){
                    $progressText.text(text || ('压缩中: ' + current + ' / ' + total));
                }
            }
            
            function finishBatchCompression(){
                batchCompressing = false;
                var $status = $('.psp-compressing-status');
                if($status.length){
                    $status.fadeOut(300, function(){
                        $status.remove();
                    });
                }
                
                // Start upload after all files are compressed
                uploader.start();
            }
            
            // Compress files in parallel (but limit concurrency)
            var maxConcurrent = 3; // Compress 3 files at a time
            var currentIndex = 0;
            var activeCompressions = 0;
            
            function processNext(){
                if(currentIndex >= totalFiles){
                    if(activeCompressions === 0){
                        finishBatchCompression();
                    }
                    return;
                }
                
                if(activeCompressions >= maxConcurrent){
                    return;
                }
                
                var file = imageFiles[currentIndex++];
                var fileId = file.id || file.name + file.size;
                
                compressingFiles.add(fileId);
                activeCompressions++;
                
                updateProgress(compressedCount + failedCount + activeCompressions, totalFiles);
                
                compressImageBeforeUpload(file, function(compressedFile){
                    compressingFiles.delete(fileId);
                    activeCompressions--;
                    
                    if(compressedFile && compressedFile.size < file.size){
                        compressedFileMap[fileId] = compressedFile;
                        compressedCount++;
                        
                        // Replace file in queue
                        try {
                            var index = uploader.files.indexOf(file);
                            if(index > -1){
                                uploader.files[index] = compressedFile;
                            }
                        } catch(err){
                            console.log('PSP: Error replacing file', err);
                        }
                    } else {
                        failedCount++;
                    }
                    
                    // Process next file
                    processNext();
                });
            }
            
            // Start processing
            for(var i = 0; i < Math.min(maxConcurrent, totalFiles); i++){
                processNext();
            }
        });
        
        // Hook into BeforeUpload to ensure compressed file is used
        $(document).on('plupload:BeforeUpload', function(e, uploader, file){
            var toggle = $('#psp-auto-compress-toggle');
            if(!toggle.length || !toggle.is(':checked')) return;
            
            var fileId = file.id || file.name + file.size;
            if(compressedFileMap[fileId]){
                // Replace file object before upload
                try {
                    var index = uploader.files.indexOf(file);
                    if(index > -1){
                        uploader.files[index] = compressedFileMap[fileId];
                    }
                } catch(err){
                    console.log('PSP: Error replacing file before upload', err);
                }
            }
        });
    }

    // Note: Only plupload method is used to avoid conflicts and duplicate processing
    // WordPress media uploader uses plupload, so other methods are disabled

    // Web Worker for compression (non-blocking, like Pic Smaller)
    var compressionWorker = null;
    var workerQueue = [];
    var isWorkerReady = false;
    
    function initCompressionWorker(){
        if(typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined'){
            return false;
        }
        
        try {
            var workerUrl = pspData.pluginUrl + 'assets/compressor-worker.js';
            compressionWorker = new Worker(workerUrl);
            compressionWorker.onmessage = function(e){
                var result = e.data;
                var queueItem = workerQueue.shift();
                
                if(result.success && result.compressedSize < result.originalSize){
                    // Create File from ArrayBuffer
                    var compressedFile = new File([result.arrayBuffer], result.fileName, {
                        type: result.fileType,
                        lastModified: Date.now()
                    });
                    queueItem.callback(compressedFile);
                } else {
                    queueItem.callback(queueItem.file);
                }
                
                // Process next item in queue
                if(workerQueue.length > 0){
                    processWorkerQueue();
                }
            };
            
            compressionWorker.onerror = function(err){
                console.log('PSP Worker Error:', err);
                // Fallback to main thread compression
                var queueItem = workerQueue.shift();
                if(queueItem){
                    compressWithOffscreenCanvas(queueItem.file, queueItem.maxWidth, queueItem.maxHeight, queueItem.quality, queueItem.callback);
                }
            };
            
            isWorkerReady = true;
            return true;
        } catch(err){
            console.log('PSP: Failed to create worker:', err);
            return false;
        }
    }
    
    function processWorkerQueue(){
        if(!isWorkerReady || workerQueue.length === 0) return;
        
        var item = workerQueue[0];
        
        // Read file as ArrayBuffer to send to worker
        var reader = new FileReader();
        reader.onload = function(e){
            var arrayBuffer = e.target.result;
            compressionWorker.postMessage({
                imageData: arrayBuffer,
                fileName: item.file.name,
                fileType: item.file.type,
                originalSize: item.file.size,
                maxWidth: item.maxWidth,
                maxHeight: item.maxHeight,
                quality: item.quality
            }, [arrayBuffer]); // Transfer ownership for better performance
        };
        reader.onerror = function(){
            // Fallback to main thread compression
            workerQueue.shift();
            compressWithOffscreenCanvas(item.file, item.maxWidth, item.maxHeight, item.quality, item.callback);
            processWorkerQueue();
        };
        reader.readAsArrayBuffer(item.file);
    }
    
    // Compress image before upload (Pure client-side, no server-side logic)
    // Inspired by Pic Smaller: https://github.com/joye61/pic-smaller
    // Uses Web Worker for non-blocking compression
    function compressImageBeforeUpload(file, callback){
        if(!file || !file.type || !file.type.match(/^image\//)){
            callback(file);
            return;
        }
        
        // Skip if file is smaller than minimum size threshold
        var minSizeBytes = (parseFloat(pspData.minSize) || 0.1) * 1024 * 1024; // Convert MB to bytes
        if(file.size < minSizeBytes){
            callback(file);
            return;
        }
        
        // Skip if file is too large (would take too long)
        if(file.size > 10 * 1024 * 1024){ // Larger than 10MB, skip compression
            callback(file);
            return;
        }
        
        var maxWidth = parseInt(pspData.maxWidth) || 2000;
        var maxHeight = parseInt(pspData.maxHeight) || 2000;
        var quality = parseFloat(pspData.quality) / 100 || 0.8;
        
        // Try to use Web Worker first (non-blocking)
        if(isWorkerReady && compressionWorker){
            workerQueue.push({
                file: file,
                maxWidth: maxWidth,
                maxHeight: maxHeight,
                quality: quality,
                callback: callback
            });
            processWorkerQueue();
        } else {
            // Fallback to main thread compression
            // Add timeout to prevent hanging
            var timeout = setTimeout(function(){
                callback(file);
            }, 8000); // 8 second timeout
            
            var callbackWrapper = function(compressedFile){
                clearTimeout(timeout);
                callback(compressedFile);
            };
            
            // Use OffscreenCanvas if available for better performance
            if(typeof OffscreenCanvas !== 'undefined'){
                compressWithOffscreenCanvas(file, maxWidth, maxHeight, quality, callbackWrapper);
            } else {
                compressWithCanvas(file, maxWidth, maxHeight, quality, callbackWrapper);
            }
        }
    }
    
    // Initialize worker on page load
    if(typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined'){
        initCompressionWorker();
    }
    
    // Compress using OffscreenCanvas (better performance, non-blocking)
    // Optimized for speed like Pic Smaller
    function compressWithOffscreenCanvas(file, maxWidth, maxHeight, quality, callback){
        // Use createImageBitmap for faster image loading (like Pic Smaller)
        if(typeof createImageBitmap !== 'undefined'){
            createImageBitmap(file).then(function(imageBitmap){
                try {
                    var width = imageBitmap.width;
                    var height = imageBitmap.height;
                    
                    // Calculate new dimensions
                    if(width > maxWidth || height > maxHeight){
                        var ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.round(width * ratio);
                        height = Math.round(height * ratio);
                    }
                    
                    // Use OffscreenCanvas for better performance
                    var offscreen = new OffscreenCanvas(width, height);
                    var ctx = offscreen.getContext('2d');
                    
                    // Set image rendering quality (optimized)
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = 'medium'; // Use medium for faster processing
                    
                    // Draw image
                    ctx.drawImage(imageBitmap, 0, 0, width, height);
                    
                    // Close ImageBitmap to free memory immediately
                    imageBitmap.close();
                    
                    // Convert to blob (async, non-blocking)
                    offscreen.convertToBlob({
                        type: file.type,
                        quality: quality
                    }).then(function(blob){
                        if(blob && blob.size < file.size){
                            var compressedFile = new File([blob], file.name, {
                                type: file.type,
                                lastModified: Date.now()
                            });
                            callback(compressedFile);
                        } else {
                            callback(file); // Use original if compression didn't help
                        }
                    }).catch(function(err){
                        console.log('PSP OffscreenCanvas Error:', err);
                        callback(file); // Fallback to original
                    });
                } catch(err){
                    console.log('PSP Compression Error:', err);
                    callback(file); // Fallback to original file
                }
            }).catch(function(err){
                // Fallback to FileReader method
                compressWithOffscreenCanvasFallback(file, maxWidth, maxHeight, quality, callback);
            });
        } else {
            // Fallback for browsers without createImageBitmap
            compressWithOffscreenCanvasFallback(file, maxWidth, maxHeight, quality, callback);
        }
    }
    
    // Fallback method using FileReader
    function compressWithOffscreenCanvasFallback(file, maxWidth, maxHeight, quality, callback){
        var reader = new FileReader();
        reader.onload = function(e){
            var img = new Image();
            img.onload = function(){
                try {
                    var width = img.width;
                    var height = img.height;
                    
                    // Calculate new dimensions
                    if(width > maxWidth || height > maxHeight){
                        var ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.round(width * ratio);
                        height = Math.round(height * ratio);
                    }
                    
                    // Use OffscreenCanvas for better performance
                    var offscreen = new OffscreenCanvas(width, height);
                    var ctx = offscreen.getContext('2d');
                    
                    // Set image rendering quality
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = 'medium';
                    
                    // Draw image
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    // Convert to blob
                    offscreen.convertToBlob({
                        type: file.type,
                        quality: quality
                    }).then(function(blob){
                        if(blob && blob.size < file.size){
                            var compressedFile = new File([blob], file.name, {
                                type: file.type,
                                lastModified: Date.now()
                            });
                            callback(compressedFile);
                        } else {
                            callback(file);
                        }
                    }).catch(function(err){
                        console.log('PSP OffscreenCanvas Error:', err);
                        callback(file);
                    });
                } catch(err){
                    console.log('PSP Compression Error:', err);
                    callback(file);
                }
            };
            img.onerror = function(){
                callback(file);
            };
            img.src = e.target.result;
        };
        reader.onerror = function(){
            callback(file);
        };
        reader.readAsDataURL(file);
    }
    
    // Compress using regular Canvas (fallback for older browsers)
    function compressWithCanvas(file, maxWidth, maxHeight, quality, callback){
        var reader = new FileReader();
        reader.onload = function(e){
            var img = new Image();
            img.onload = function(){
                try {
                    var canvas = document.createElement('canvas');
                    var ctx = canvas.getContext('2d');
                    
                    var width = img.width;
                    var height = img.height;
                    var originalSize = width * height;
                    
                    // Only compress if image is large enough (optimized)
                    if(originalSize < 50000){ // Very small images, skip compression
                        callback(file);
                        return;
                    }
                    
                    // Calculate new dimensions
                    if(width > maxWidth || height > maxHeight){
                        var ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.round(width * ratio);
                        height = Math.round(height * ratio);
                    }
                    
                    canvas.width = width;
                    canvas.height = height;
                    
                    // Set image rendering quality
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = 'high';
                    
                    // Handle transparency for PNG/GIF
                    if(file.type === 'image/png' || file.type === 'image/gif'){
                        // Preserve transparency for PNG
                        if(file.type === 'image/png'){
                            ctx.globalCompositeOperation = 'source-over';
                        } else {
                            // For GIF, fill white background
                            ctx.fillStyle = '#FFFFFF';
                            ctx.fillRect(0, 0, width, height);
                        }
                    }
                    
                    // Draw image
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    // Convert to blob with quality settings
                    canvas.toBlob(function(blob){
                        if(blob && blob.size < file.size){
                            var compressedFile = new File([blob], file.name, {
                                type: file.type,
                                lastModified: Date.now()
                            });
                            callback(compressedFile);
                        } else {
                            callback(file); // Use original if compression didn't help
                        }
                    }, file.type, quality);
                } catch(err){
                    console.log('PSP Compression Error:', err);
                    callback(file); // Fallback to original file
                }
            };
            img.onerror = function(){
                callback(file); // Fallback to original file
            };
            img.src = e.target.result;
        };
        reader.onerror = function(){
            callback(file); // Fallback to original file
        };
        reader.readAsDataURL(file);
    }
});
