// Web Worker for image compression (inspired by Pic Smaller)
// This runs in a separate thread, so it doesn't block the main UI

self.onmessage = function(e) {
    var data = e.data;
    var imageData = data.imageData; // Base64 or ArrayBuffer
    var fileName = data.fileName;
    var fileType = data.fileType;
    var originalSize = data.originalSize;
    var maxWidth = data.maxWidth || 2000;
    var maxHeight = data.maxHeight || 2000;
    var quality = data.quality || 0.8;
    
    try {
        // Create ImageBitmap from image data
        var imageBitmap = null;
        
        if(imageData instanceof ArrayBuffer){
            // Convert ArrayBuffer to Blob
            var blob = new Blob([imageData], { type: fileType });
            createImageBitmap(blob).then(function(bitmap){
                processImage(bitmap, fileType, originalSize, maxWidth, maxHeight, quality, fileName);
            }).catch(function(err){
                self.postMessage({
                    success: false,
                    error: 'Failed to create ImageBitmap: ' + err.message
                });
            });
        } else if(typeof imageData === 'string'){
            // Base64 string
            var byteCharacters = atob(imageData.split(',')[1] || imageData);
            var byteNumbers = new Array(byteCharacters.length);
            for(var i = 0; i < byteCharacters.length; i++){
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            var blob = new Blob([byteArray], { type: fileType });
            
            createImageBitmap(blob).then(function(bitmap){
                processImage(bitmap, fileType, originalSize, maxWidth, maxHeight, quality, fileName);
            }).catch(function(err){
                self.postMessage({
                    success: false,
                    error: 'Failed to create ImageBitmap: ' + err.message
                });
            });
        } else {
            self.postMessage({
                success: false,
                error: 'Unsupported image data format'
            });
        }
    } catch(err){
        self.postMessage({
            success: false,
            error: err.message
        });
    }
};

function processImage(imageBitmap, fileType, originalSize, maxWidth, maxHeight, quality, fileName){
    try {
        var width = imageBitmap.width;
        var height = imageBitmap.height;
        
        // Calculate new dimensions
        if(width > maxWidth || height > maxHeight){
            var ratio = Math.min(maxWidth / width, maxHeight / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
        }
        
        // Use OffscreenCanvas for better performance
        var offscreen = new OffscreenCanvas(width, height);
        var ctx = offscreen.getContext('2d');
        
        // Set image rendering quality
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        
        // Draw image
        ctx.drawImage(imageBitmap, 0, 0, width, height);
        
        // Close ImageBitmap to free memory
        imageBitmap.close();
        
        // Convert to blob
        offscreen.convertToBlob({
            type: fileType,
            quality: quality
        }).then(function(compressedBlob){
            // Send compressed blob back as ArrayBuffer
            compressedBlob.arrayBuffer().then(function(arrayBuffer){
                self.postMessage({
                    success: true,
                    arrayBuffer: arrayBuffer,
                    fileType: fileType,
                    fileName: fileName,
                    originalSize: originalSize,
                    compressedSize: compressedBlob.size
                }, [arrayBuffer]); // Transfer ownership for better performance
            });
        }).catch(function(err){
            self.postMessage({
                success: false,
                error: 'Failed to convert to blob: ' + err.message
            });
        });
    } catch(err){
        self.postMessage({
            success: false,
            error: err.message
        });
    }
}

