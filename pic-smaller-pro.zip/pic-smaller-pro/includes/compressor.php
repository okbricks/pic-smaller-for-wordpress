<?php
if (!defined('ABSPATH')) exit;

function psp_compress_image($file){
    if(!file_exists($file)){
        error_log('PSP: File not found - ' . $file);
        return false;
    }
    
    // Check file permissions
    if(!is_readable($file)){
        error_log('PSP: File not readable - ' . $file);
        return false;
    }
    
    if(!is_writable($file)){
        error_log('PSP: File not writable - ' . $file);
        return false;
    }
    
    $quality = get_option('psp_quality', 80);
    $mw = get_option('psp_max_width', 2000);
    $mh = get_option('psp_max_height', 2000);

    $mime = @mime_content_type($file);
    if(!$mime){
        // Fallback to file extension
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mime_map = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif'
        ];
        $mime = isset($mime_map[$ext]) ? $mime_map[$ext] : '';
    }
    
    if(!in_array($mime, ['image/jpeg', 'image/png', 'image/gif'])){
        error_log('PSP: Unsupported MIME type - ' . $mime . ' for file ' . $file);
        return false;
    }
    
    $image_info = @getimagesize($file);
    if(!$image_info){
        error_log('PSP: Cannot read image info - ' . $file);
        return false;
    }
    
    list($w, $h) = $image_info;
    
    // Check if image is too large (memory check)
    $memory_needed = ($w * $h * 4) / 1024 / 1024; // Rough estimate in MB
    $memory_limit = ini_get('memory_limit');
    $memory_limit_bytes = psp_convert_to_bytes($memory_limit);
    $memory_usage = memory_get_usage(true);
    $available_memory = ($memory_limit_bytes - $memory_usage) / 1024 / 1024;
    
    if($memory_needed > $available_memory * 0.5){
        error_log(sprintf('PSP: Insufficient memory - Need: %.2fMB, Available: %.2fMB', $memory_needed, $available_memory));
        return false;
    }

    // Use Imagick if available
    if(class_exists('Imagick')){
        try {
            $img = new Imagick($file);
            
            // Resize
            if($w > $mw || $h > $mh){
                $ratio = min($mw/$w, $mh/$h);
                $nw = intval($w * $ratio);
                $nh = intval($h * $ratio);
                $img->resizeImage($nw, $nh, Imagick::FILTER_LANCZOS, 1);
            }
            
            // Compress
            $img->setImageCompressionQuality($quality);
            $img->stripImage();
            $img->writeImage($file);
            
            $img->destroy();
            return true;
        } catch(Exception $e) {
            error_log('PSP Imagick Error: ' . $e->getMessage());
        }
    }
    
    // Fallback to GD
    if(function_exists('imagecreatefromjpeg') || function_exists('imagecreatefrompng')){
        try {
            $src = null;
            if($mime == 'image/jpeg' && function_exists('imagecreatefromjpeg')){
                $src = imagecreatefromjpeg($file);
            } elseif($mime == 'image/png' && function_exists('imagecreatefrompng')){
                $src = imagecreatefrompng($file);
            } elseif($mime == 'image/gif' && function_exists('imagecreatefromgif')){
                $src = imagecreatefromgif($file);
            }
            
            if(!$src) return false;
            
            // Resize
            if($w > $mw || $h > $mh){
                $ratio = min($mw/$w, $mh/$h);
                $nw = intval($w * $ratio);
                $nh = intval($h * $ratio);
                $dst = imagecreatetruecolor($nw, $nh);
                
                if($mime == 'image/png'){
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                }
                
                imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagedestroy($src);
                $src = $dst;
            }
            
            // Save original format
            if($mime == 'image/jpeg'){
                imagejpeg($src, $file, $quality);
            } elseif($mime == 'image/png'){
                imagepng($src, $file, 9 - round($quality/10));
            } elseif($mime == 'image/gif'){
                imagegif($src, $file);
            }
            
            imagedestroy($src);
            return true;
        } catch(Exception $e) {
            error_log('PSP GD Error: ' . $e->getMessage());
        }
    }
    
    return false;
}

// Helper function to convert memory limit string to bytes
function psp_convert_to_bytes($val){
    $val = trim($val);
    $last = strtolower($val[strlen($val)-1]);
    $val = (int)$val;
    switch($last){
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }
    return $val;
}

// Get compression status and diagnostics
function psp_get_compression_status($file){
    $status = [
        'file_exists' => file_exists($file),
        'readable' => file_exists($file) ? is_readable($file) : false,
        'writable' => file_exists($file) ? is_writable($file) : false,
        'mime_type' => '',
        'image_info' => false,
        'imagick_available' => class_exists('Imagick'),
        'gd_available' => function_exists('imagecreatefromjpeg') || function_exists('imagecreatefrompng'),
        'file_size' => file_exists($file) ? filesize($file) : 0,
        'error' => ''
    ];
    
    if(!$status['file_exists']){
        $status['error'] = '文件不存在';
        return $status;
    }
    
    if(!$status['readable']){
        $status['error'] = '文件不可读（权限问题）';
        return $status;
    }
    
    if(!$status['writable']){
        $status['error'] = '文件不可写（权限问题）';
        return $status;
    }
    
    $mime = @mime_content_type($file);
    if(!$mime){
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mime_map = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif'
        ];
        $mime = isset($mime_map[$ext]) ? $mime_map[$ext] : '';
    }
    $status['mime_type'] = $mime;
    
    if(!in_array($mime, ['image/jpeg', 'image/png', 'image/gif'])){
        $status['error'] = '不支持的图片格式: ' . $mime;
        return $status;
    }
    
    $image_info = @getimagesize($file);
    if(!$image_info){
        $status['error'] = '无法读取图片信息（可能文件损坏）';
        return $status;
    }
    $status['image_info'] = $image_info;
    
    if(!$status['imagick_available'] && !$status['gd_available']){
        $status['error'] = '服务器未安装 Imagick 或 GD 扩展';
        return $status;
    }
    
    return $status;
}
