<?php
/**
 * Plugin Name: Pic Smaller PRO
 * Description: Professional image compression plugin. Bulk compress, quality control, resize.
 * Version: 1.3
 * Author: Project0ne (121696015@qq.com)
 */
if (!defined('ABSPATH')) exit;

define('PSP_VERSION', '1.3');
define('PSP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PSP_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once PSP_PLUGIN_PATH . 'includes/compressor.php';
require_once PSP_PLUGIN_PATH . 'includes/batch.php';
require_once PSP_PLUGIN_PATH . 'admin/settings-page.php';

// Upload optimization hook
add_filter('wp_handle_upload', 'psp_optimize_upload');
function psp_optimize_upload($upload){
    if(get_option('psp_auto_compress', true)){
        psp_compress_image($upload['file']);
    }
    return $upload;
}

// Admin menu
add_action('admin_menu', function(){
    add_menu_page(
        'Pic Smaller PRO',
        'Pic Smaller PRO',
        'manage_options',
        'pic-smaller-pro',
        'psp_render_settings_page',
        'dashicons-image-filter',
        80
    );
});

// AJAX handlers
add_action('wp_ajax_psp_batch_compress', 'psp_batch_compress');
add_action('wp_ajax_psp_compress_single', 'psp_compress_single');
add_action('wp_ajax_psp_toggle_auto_compress', 'psp_toggle_auto_compress');

// Toggle auto compress
function psp_toggle_auto_compress(){
    check_ajax_referer('psp_action', 'nonce');
    if(!current_user_can('manage_options')){
        wp_send_json_error('权限不足');
        return;
    }
    
    $enabled = isset($_POST['enabled']) && intval($_POST['enabled']) == 1;
    update_option('psp_auto_compress', $enabled);
    wp_send_json_success(['enabled' => $enabled]);
}

// Single image compression
function psp_compress_single(){
    check_ajax_referer('psp_action', 'nonce');
    if(!current_user_can('upload_files')){
        wp_send_json_error('权限不足');
        return;
    }
    
    $id = intval($_POST['id']);
    $file = get_attached_file($id);
    
    if($file && file_exists($file)){
        // Get diagnostic info
        $status = psp_get_compression_status($file);
        if(!empty($status['error'])){
            wp_send_json_error('压缩失败: ' . $status['error']);
            return;
        }
        
        $original_size = filesize($file);
        $result = psp_compress_image($file);
        if($result){
            $new_size = filesize($file);
            $saved = $original_size - $new_size;
            $percent = $original_size > 0 ? round(($saved / $original_size) * 100, 1) : 0;
            $message = sprintf('压缩成功！原大小: %s, 新大小: %s, 节省: %s (%.1f%%)', 
                size_format($original_size), 
                size_format($new_size), 
                size_format($saved), 
                $percent
            );
            wp_send_json_success($message);
        } else {
            wp_send_json_error('压缩失败: 可能是文件格式不支持、内存不足或权限问题');
        }
    } else {
        wp_send_json_error('文件不存在');
    }
}

// Add bulk actions to media library
add_filter('bulk_actions-upload', 'psp_add_bulk_actions');
function psp_add_bulk_actions($actions){
    $actions['psp_bulk_compress'] = '批量压缩';
    return $actions;
}

// Handle bulk actions
add_filter('handle_bulk_actions-upload', 'psp_handle_bulk_actions', 10, 3);
function psp_handle_bulk_actions($redirect_to, $action, $post_ids){
    if($action == 'psp_bulk_compress'){
        $success = 0;
        $failed = 0;
        
        foreach($post_ids as $id){
            $file = get_attached_file($id);
            if($file && file_exists($file)){
                $result = psp_compress_image($file);
                if($result){
                    $success++;
                } else {
                    $failed++;
                }
            } else {
                $failed++;
            }
        }
        
        $redirect_to = add_query_arg([
            'psp_bulk_done' => 1,
            'success' => $success,
            'failed' => $failed
        ], $redirect_to);
    }
    
    return $redirect_to;
}

// Show bulk action notice
add_action('admin_notices', 'psp_bulk_action_notice');
function psp_bulk_action_notice(){
    if(isset($_GET['psp_bulk_done'])){
        $success = intval($_GET['success']);
        $failed = intval($_GET['failed']);
        echo '<div class="notice notice-success is-dismissible"><p>';
        echo sprintf('批量处理完成：成功 %d 张，失败 %d 张', $success, $failed);
        echo '</p></div>';
    }
}

// Enqueue admin scripts
add_action('admin_enqueue_scripts', 'psp_admin_scripts');
function psp_admin_scripts($hook){
    if($hook == 'upload.php' || $hook == 'media-new.php' || $hook == 'toplevel_page_pic-smaller-pro'){
        wp_enqueue_script('psp-admin', PSP_PLUGIN_URL . 'assets/admin.js', ['jquery'], PSP_VERSION, true);
        wp_enqueue_style('psp-admin', PSP_PLUGIN_URL . 'assets/admin.css', [], PSP_VERSION);
        wp_localize_script('psp-admin', 'pspData', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('psp_action'),
            'batchNonce' => wp_create_nonce('psp_batch_action'),
            'autoCompress' => get_option('psp_auto_compress', true),
            'maxWidth' => get_option('psp_max_width', 2000),
            'maxHeight' => get_option('psp_max_height', 2000),
            'quality' => get_option('psp_quality', 80),
            'minSize' => get_option('psp_min_size', 0.1), // MB
            'pluginUrl' => PSP_PLUGIN_URL
        ]);
    }
}
